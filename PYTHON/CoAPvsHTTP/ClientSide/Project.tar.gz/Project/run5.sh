#!/bin/sh
cd /home/umakant
ip="2001:470:8865:4001:192:168:146:129"
coapclient.py -o GET -p coap://[$ip]:5683/Voltage 601
#ip=$(ip -f inet -o addr show ens38|cut -d\  -f 7 | cut -d/ -f 1) - If Server is running on same Host
#ip="192.168.146.129"
#coapclient.py -o GET -p coap://$ip:5683/Voltage 300
